Como compilar:
*python main.py
-para execuatar o servidor
*python main1.py
-para executar os clientes
Legenda do terminal:
Flipagem: 0-n�o ocorre flipagem de bits
	  1-flipagem dos bits �mpares
	  2-flipagem dos bits pares
	  3-flipagem randomica
Componentes:
Eliandra    11/0148053
Isabella    11/0031423
Jo�o Victor 10/0107656
Lucas       11/0015975
Rafael	    11/0056001
Vers�o python: 2.7